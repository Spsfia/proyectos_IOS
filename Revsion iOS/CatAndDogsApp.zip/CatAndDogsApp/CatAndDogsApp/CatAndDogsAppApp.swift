//
//  CatAndDogsAppApp.swift
//  CatAndDogsApp
//
//  Created by Adriana Sofia on 13/12/24.
//

import SwiftUI

@main
struct CatAndDogsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
