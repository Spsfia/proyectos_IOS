//
//  Dog.swift
//  FirebaseApp
//
//  Created by Adriana Sofia on 15/12/24.
//

import SwiftUI

struct Dog: Identifiable{
    var id: String
    var breed: String
    
    
}
