//
//  FirebaseAppTests.swift
//  FirebaseAppTests
//
//  Created by Adriana Sofia on 15/12/24.
//

import Testing
@testable import FirebaseApp

struct FirebaseAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
