//
//  DirectionsApp.swift
//  Directions
//

import SwiftUI

@main
struct DirectionsApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
