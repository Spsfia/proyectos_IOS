//
//  AppDelegate.h
//  appCartas
//
//  Created by Adriana Sofia on 24/11/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

