//
//  PlayingCardDeck.h
//  appCartas
//
//  Created by Adriana Sofia on 24/11/24.
//

#import "Deck.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlayingCardDeck : Deck

@end

NS_ASSUME_NONNULL_END
