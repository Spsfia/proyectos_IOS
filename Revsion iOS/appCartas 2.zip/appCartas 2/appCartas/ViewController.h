//
//  ViewController.h
//  appCartas
//
//  Created by Adriana Sofia on 24/11/24.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *livesLabel; // UILabel para mostrar vidas


@end

