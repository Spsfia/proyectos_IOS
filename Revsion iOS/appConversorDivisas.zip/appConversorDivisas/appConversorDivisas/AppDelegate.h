//
//  AppDelegate.h
//  appConversorDivisas
//
//  Created by Adriana Sofia on 21/10/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

