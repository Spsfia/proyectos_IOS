//
//  SceneDelegate.h
//  appConversorDivisas
//
//  Created by Adriana Sofia on 21/10/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

