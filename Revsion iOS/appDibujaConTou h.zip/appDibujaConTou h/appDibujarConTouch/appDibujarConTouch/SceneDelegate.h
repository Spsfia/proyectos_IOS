//
//  SceneDelegate.h
//  appDibujarConTouch
//
//  Created by Guest User on 29/10/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

