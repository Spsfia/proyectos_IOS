//
//  ViewController.m
//  appDibujarConTouch
//
//  Created by Guest User on 29/10/24.
//

#import "ViewController.h"
#import "DibujarConTouch.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

}


@end
