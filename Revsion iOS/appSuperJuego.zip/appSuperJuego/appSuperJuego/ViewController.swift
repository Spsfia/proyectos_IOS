//
//  ViewController.swift
//  appSuperJuego
//
//  Created by Adriana Sofia on 10/11/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

